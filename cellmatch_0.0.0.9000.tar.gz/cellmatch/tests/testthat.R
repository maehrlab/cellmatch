library(testthat)
library(clearmatch)

test_check("clearmatch")
