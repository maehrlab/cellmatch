## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo = F----------------------------------------------------------
knitr::opts_chunk$set(
  results = "hide", 
  fig.show='hide',
  warning = FALSE ,
  message = FALSE
)

## -----------------------------------------------------------------------------
library(cellmatch)
library(magrittr)
results_path = getwd()
# query
mpfe_query = cellmatch::mPFE_diff
# endoderm E3.5 to E11.5
endoderm_reference = cellmatch::MergeMatrixList( list( cellmatch::early_endoderm_reference %>% as.matrix,
                                                       cellmatch::reference_3pp %>% as.matrix ) )
# endoderm with whole embryo for contaminant detection
whole_plus_endo_genes = intersect(rownames(cellmatch::whole_embryo_8_75), 
                                  rownames(endoderm_reference))
whole_plus_endo = cbind(cellmatch::whole_embryo_8_75[whole_plus_endo_genes,], 
                        endoderm_reference[whole_plus_endo_genes,])

## -----------------------------------------------------------------------------
shared_genes_whole = intersect(rownames(whole_plus_endo), rownames(mpfe_query))
match_out = cellmatch::RunCellMatch(
  query     = mpfe_query[     shared_genes_whole,],
  reference = whole_plus_endo[shared_genes_whole,],
  results_path = results_path %>% file.path("contaminant_detection")
)
match_out$heatmap
exclude = c("mPFE_6_c6", "mDE_c2") #endothelium, mesendoderm
query_clean = mpfe_query[,setdiff(colnames(mpfe_query), exclude)]

## -----------------------------------------------------------------------------
shared_genes_endo = intersect(rownames(mpfe_query), rownames(endoderm_reference))
match_endo = cellmatch::RunCellMatch(
  query     = query_clean[       shared_genes_endo,],
  reference = endoderm_reference[shared_genes_endo,],
  results_path = results_path %>% file.path("endoderm_staging")
)
match_endo$heatmap

## -----------------------------------------------------------------------------
results_path %>% file.path("endoderm_staging") %>% unlink(recursive = T)
results_path %>% file.path("contaminant_detection") %>% unlink(recursive = T)

